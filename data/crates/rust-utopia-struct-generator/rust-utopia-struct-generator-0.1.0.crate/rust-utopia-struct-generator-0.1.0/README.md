# rust-utoipa-struct-generator

A [proc_macro](https://doc.rust-lang.org/proc_macro/) that, when given a struct as a parameter, will expand the struct into a formatted response used by the [Utoipa](https://docs.rs/utoipa/latest/utoipa/) OpenAPI documentation generator. This prevents Rust developers who document using Utoipa from needing to create and maintain two definitions for the result of every query: one for use by the code, and one for use by the documentation.

## Example Usage

```rust
// One of our queries returns a response of type DataModel.
// Here, we define the struct.

#[derive(Clone, Debug, Serialize, Deserialize, FromRow, ToSchema)]
pub struct DataModel {
  pub measurement: Option<u16>,
  pub reading: Option<u16>,
  pub value: Option<String>,
}

// Now we call our gen_openapi_struct macro, passing it the DataModel
// struct as its only argument. Directly beneath the macro call, we name 
// the struct that our DataModel will expand into.

#[gen_openapi_struct(DataModel)]
pub struct DataModelUtoipa;

// gen_openapi_struct expands DataModel into the following:

pub DataModelUtoipa {
  pub code: u16,
  pub data: Option<DataModel>,
  pub error_code: Option<String>,
  pub error_message: Option<String>,
  pub link: String,
  pub status: RequestStatus,
  pub time: String
}

// This struct can be used in our Utoipa decorations. Here, we use it to
// define the response shape for our /data-model endpoint:

#[utoipa::path(
    get,
    path = "/data-model",
    responses (
        (status = 200, description = "Gets the data model", body = DataModelUtoipa)
    )
)]
#[get("/data-model")]
```