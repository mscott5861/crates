use std::{vec, str::FromStr};

use proc_macro::{TokenStream};
use proc_macro2::{TokenStream as Ts2, TokenTree as Tt2, Punct as Punct2};
use syn::{parse_macro_input, ItemStruct, __private::{quote::{quote}, Span as Span2, ToTokens}
, Ident as Ident2};

/*
    ToDo: Is there a way to resolve Serialize, Deserialize, etc, at
    this spot, rather than being forced to include them via use
    statements at the call location?
*/
#[proc_macro_attribute]
pub fn gen_openapi_struct(args: TokenStream, input: TokenStream) -> TokenStream {
    let span = Span2::call_site();
    let mut arg_iter = args.into_iter();
    let type_tree = arg_iter.next().unwrap();
    let type_string = match type_tree {
        proc_macro::TokenTree::Ident(ident) => {
            Some(ident.to_string())
        },
        _ => None
    }.unwrap();
    let ts = match type_string.as_ref() {
        "Vec" => {
            let _ = arg_iter.next(); // Move past first punctuation mark.
            let struct_type_ident = match arg_iter.next().unwrap() {
                proc_macro::TokenTree::Ident(ident) => 
                 Some(Ident2::new(&ident.to_string(), span)),
                _ => None
            }.unwrap();
            let token_tree_vec = vec![
                Tt2::Ident(Ident2::new("Vec", span)),
                Tt2::Punct(
                    Punct2::new('<', proc_macro2::Spacing::Alone)),
                Tt2::Ident(struct_type_ident),
                Tt2::Punct(
                    Punct2::new('>', proc_macro2::Spacing::Alone))
            ];
            Ts2::from_iter(token_tree_vec)
        },
        _ => {
            Ts2::from_str(&type_string).unwrap()
        }
        
    }.into_iter();

    let item_struct = parse_macro_input!(input as ItemStruct);
    let vis = item_struct.vis;
    let struct_name = item_struct.ident;
    quote!(
        #[derive(ToSchema)]
        #vis struct #struct_name {
            pub code: u16,
            pub data: Option<#(#ts)*>,
            // This is reserved for potential future use. Currently,
            // it is probably going to wind up matching the HTTP
            // error code, if any.
            pub error_code: Option<String>,
            pub error_message: Option<String>,
            pub link: String,
            pub status: RequestStatus,
            pub time: String
        }
    ).into()
}
